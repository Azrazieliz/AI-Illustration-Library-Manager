Copy the 'engine' folder into the repository generated in Phase 1, replacing/merging folders.
Future milestones will continue extending the same repository.
