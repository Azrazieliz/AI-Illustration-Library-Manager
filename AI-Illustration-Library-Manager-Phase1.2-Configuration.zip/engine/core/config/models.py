from dataclasses import dataclass
from pathlib import Path

@dataclass(frozen=True)
class DatabaseConfig:
    backend: str
    path: Path

@dataclass(frozen=True)
class ApplicationConfig:
    name: str
    version: str
    database: DatabaseConfig
