from pathlib import Path
import yaml
from .models import *

def load_config(path: Path)->ApplicationConfig:
    data=yaml.safe_load(path.read_text(encoding='utf-8'))
    return ApplicationConfig(
        name=data['application']['name'],
        version=data['application']['version'],
        database=DatabaseConfig(
            backend=data['database']['backend'],
            path=Path(data['database']['path'])
        )
    )
