from pathlib import Path
from .loader import load_config
from .models import ApplicationConfig

class ConfigService:
    _cfg: ApplicationConfig|None=None

    @classmethod
    def initialize(cls,path:Path):
        cls._cfg=load_config(path)

    @classmethod
    def config(cls)->ApplicationConfig:
        if cls._cfg is None:
            raise RuntimeError('Configuration not initialized')
        return cls._cfg
