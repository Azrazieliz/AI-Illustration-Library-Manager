# Architecture

This document will be expanded throughout development.
