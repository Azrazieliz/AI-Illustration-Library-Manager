from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

for folder in ("data","logs","cache","cache/thumbnails","cache/embeddings"):
    (ROOT/folder).mkdir(parents=True, exist_ok=True)

print("Project initialized.")
